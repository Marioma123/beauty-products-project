/*This .JS file has a couple of constant reponses within the Chat */

const responseObj = {
  hello: "Hello! How can we help you ?",
  Hello: "Hello! How can we help you ?",
  hey: "Hey! How can we assist you?",
  Hey: "Hey! How can we assist you?",
  help: "How can we help?",
  Goodmorning: "Goodmorning, Beautiful!",
  today: new Date().toDateString(),
  time: new Date().toLocaleTimeString(),
};
